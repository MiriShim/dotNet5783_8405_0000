﻿using BlImlementation;
using DAL;
using DalAPI;

namespace BlApi;

public interface IOrder:ICRUD <BO.Order >
{
    
}
