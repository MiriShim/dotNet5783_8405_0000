﻿namespace DAL
{
    internal interface IInit
    {
        void Init();
    }
}