﻿namespace BlTest
{
    internal class Person
    {
        public Person()
        {
        }

        public object Name { get; internal set; }
    }
}