﻿namespace DO;
public enum ProductStatus
{
    State1=1,
    State2,
    State3,
    State4,
    State5,
    State6
}