﻿namespace DO;

public struct OrderItem
{
    public int OrderID { get; set; }
    public int ProductID { get; set; }
    public double Price { get; set; }
    public int Amount { get; set; }
}
