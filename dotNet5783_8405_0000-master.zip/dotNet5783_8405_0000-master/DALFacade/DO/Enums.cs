﻿namespace DO;

public enum Category
{
    Flowers,
    Seeds,
    Trees,
    /// <summary>
    /// עציצים
    /// </summary>
    Pots,
    /// <summary>
    /// כלי גינון
    /// </summary>
    GardeningTools,
    /// <summary>
    /// פקעות
    /// </summary>
    Tubers,
    /// <summary>
    /// תערובת שתילה
    /// </summary>
    plantingMixture,
    /// <summary>
    /// דשן
    /// </summary>
    Fertilizer

}